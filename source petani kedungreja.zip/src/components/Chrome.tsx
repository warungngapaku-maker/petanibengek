import { AnimatePresence, motion } from 'framer-motion'
import { Moon, ShieldCheck, Sprout, Sun } from 'lucide-react'
import { LEGAL_TEXT, LEGAL_TITLE } from '@/lib/sop'
import { spring } from './ui'

export function Header({ dark, onToggle }: { dark: boolean; onToggle: () => void }) {
  return (
    <header className="sticky top-0 z-30 -mx-4 mb-2 px-4 pt-[max(env(safe-area-inset-top),12px)] pb-3">
      <div className="absolute inset-0 border-b border-line bg-glass-strong backdrop-blur-xl" />
      <div className="relative flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="relative grid size-11 place-items-center rounded-2xl bg-gradient-to-br from-emerald-deep to-bio shadow-[0_8px_24px_-6px_rgb(5_150_105/0.7)] ring-1 ring-white/10">
            <Sprout className="size-6 text-neon" strokeWidth={2.4} />
          </div>
          <div className="leading-tight">
            <div className="text-[15px] font-extrabold tracking-tight text-ink">Petani Kedungreja</div>
            <div className="mt-0.5 flex items-center gap-1.5 text-[10.5px] font-semibold text-ink-2">
              <span className="relative flex size-2">
                <span className="absolute inline-flex size-full animate-ping rounded-full bg-neon opacity-75" />
                <span className="relative inline-flex size-2 rounded-full bg-neon" />
              </span>
              SOP Kementan RI 100% Complete
            </div>
          </div>
        </div>
        <motion.button
          whileTap={{ scale: 0.88, rotate: -15 }}
          transition={spring}
          onClick={onToggle}
          aria-label={dark ? 'Aktifkan mode terang' : 'Aktifkan mode gelap'}
          className="grid size-12 place-items-center rounded-2xl bg-chip text-ink ring-1 ring-line"
        >
          <AnimatePresence mode="wait" initial={false}>
            <motion.span
              key={dark ? 'moon' : 'sun'}
              initial={{ opacity: 0, rotate: -90, scale: 0.5 }}
              animate={{ opacity: 1, rotate: 0, scale: 1 }}
              exit={{ opacity: 0, rotate: 90, scale: 0.5 }}
              transition={{ duration: 0.2 }}
            >
              {dark ? <Moon className="size-5" /> : <Sun className="size-5 text-gold" />}
            </motion.span>
          </AnimatePresence>
        </motion.button>
      </div>
    </header>
  )
}

export function DisclaimerModal({ open, onAccept }: { open: boolean; onAccept: () => void }) {
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 p-3 backdrop-blur-md sm:items-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <motion.div
            role="dialog"
            aria-modal="true"
            aria-labelledby="disc-title"
            initial={{ y: 80, opacity: 0, scale: 0.96 }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            exit={{ y: 80, opacity: 0 }}
            transition={{ type: 'spring', stiffness: 260, damping: 26 }}
            className="relative w-full max-w-md overflow-hidden rounded-[30px] border border-white/10 bg-[#06201d]/90 p-6 text-white shadow-2xl backdrop-blur-2xl"
          >
            <div aria-hidden className="absolute -top-24 left-1/2 size-64 -translate-x-1/2 rounded-full bg-neon/25 blur-3xl" />
            <div className="relative">
              <div className="mx-auto mb-4 grid size-16 place-items-center rounded-3xl bg-gradient-to-br from-bio to-neon shadow-[0_10px_40px_-6px_rgb(132_204_22/0.7)]">
                <ShieldCheck className="size-8 text-emerald-deep" strokeWidth={2.4} />
              </div>
              <h2 id="disc-title" className="text-center text-xl font-extrabold tracking-tight">
                Sebelum Anda Mulai
              </h2>
              <p className="mt-1 text-center text-sm text-emerald-100/70">
                Kalkulator Pemupukan Padi Presisi & Nutrisi Foliar
              </p>
              <div className="mt-5 max-h-[40vh] overflow-y-auto rounded-2xl border border-gold/30 bg-gold/10 p-4">
                <div className="text-[11px] font-extrabold tracking-wide text-amber-300">{LEGAL_TITLE}</div>
                <p className="mt-2 text-[13px] leading-relaxed text-amber-50/85">{LEGAL_TEXT}</p>
              </div>
              <motion.button
                whileTap={{ scale: 0.96 }}
                transition={spring}
                onClick={onAccept}
                className="mt-5 min-h-14 w-full rounded-2xl bg-gradient-to-r from-bio to-neon text-[15px] font-extrabold text-emerald-deep shadow-[0_12px_32px_-8px_rgb(132_204_22/0.8)]"
              >
                Saya Mengerti & Lanjutkan
              </motion.button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
