import { animate, motion, useMotionValue, useTransform } from 'framer-motion'
import { useEffect, type ReactNode } from 'react'
import { fmt } from '@/lib/sop'

export const spring = { type: 'spring', stiffness: 420, damping: 30 } as const

export function GlassCard({
  children,
  className = '',
  glow,
}: {
  children: ReactNode
  className?: string
  glow?: string
}) {
  return (
    <div className={`relative ${className}`}>
      {glow && (
        <div
          aria-hidden
          className="pointer-events-none absolute -inset-1 rounded-[30px] opacity-60 blur-2xl dark:opacity-45"
          style={{ background: glow }}
        />
      )}
      <div className="relative h-full rounded-[26px] border border-line bg-glass p-5 shadow-[0_1px_0_rgb(255_255_255/0.06)_inset,0_20px_40px_-24px_rgb(0_0_0/0.45)] backdrop-blur-xl">
        {children}
      </div>
    </div>
  )
}

export function SectionTitle({ icon, eyebrow, title }: { icon?: ReactNode; eyebrow?: string; title: string }) {
  return (
    <div className="mb-3 flex items-center gap-3 px-1">
      {icon && (
        <div className="grid size-9 place-items-center rounded-xl bg-gradient-to-br from-bio/25 to-neon/15 text-neon ring-1 ring-neon/25">
          {icon}
        </div>
      )}
      <div>
        {eyebrow && <div className="text-[10px] font-bold uppercase tracking-[0.18em] text-ink-3">{eyebrow}</div>}
        <h2 className="text-[15px] font-bold leading-tight text-ink">{title}</h2>
      </div>
    </div>
  )
}

export function Segmented<T extends string>({
  value,
  onChange,
  options,
  id,
  tone = 'green',
}: {
  value: T
  onChange: (v: T) => void
  options: { value: T; label: string; sub?: string; icon?: ReactNode }[]
  id: string
  tone?: 'green' | 'gold'
}) {
  const active =
    tone === 'gold'
      ? 'bg-gradient-to-br from-gold to-amber-500 shadow-[0_8px_24px_-8px_rgb(217_119_6/0.7)]'
      : 'bg-gradient-to-br from-bio to-emerald-500 shadow-[0_8px_24px_-8px_rgb(5_150_105/0.8)]'
  return (
    <div
      role="radiogroup"
      className="grid gap-1.5 rounded-2xl bg-chip p-1.5 ring-1 ring-line"
      style={{ gridTemplateColumns: `repeat(${options.length}, minmax(0, 1fr))` }}
    >
      {options.map((o) => {
        const on = o.value === value
        return (
          <motion.button
            key={o.value}
            role="radio"
            aria-checked={on}
            whileTap={{ scale: 0.95 }}
            transition={spring}
            onClick={() => onChange(o.value)}
            className={`relative min-h-12 rounded-xl px-2 py-2 text-center text-[12px] font-semibold leading-tight transition-colors ${
              on ? 'text-white' : 'text-ink-2'
            }`}
          >
            {on && <motion.span layoutId={`seg-${id}`} transition={spring} className={`absolute inset-0 rounded-xl ${active}`} />}
            <span className="relative flex flex-col items-center gap-0.5">
              {o.icon}
              <span>{o.label}</span>
              {o.sub && <span className={`text-[10px] font-medium ${on ? 'text-white/80' : 'text-ink-3'}`}>{o.sub}</span>}
            </span>
          </motion.button>
        )
      })}
    </div>
  )
}

export function AnimatedNumber({ value, digits = 1, className = '' }: { value: number; digits?: number; className?: string }) {
  const mv = useMotionValue(value)
  const text = useTransform(mv, (v) => fmt(v, digits))
  useEffect(() => {
    const c = animate(mv, value, { type: 'spring', stiffness: 120, damping: 22 })
    return () => c.stop()
  }, [value, mv])
  return <motion.span className={`tabular ${className}`}>{text}</motion.span>
}

export function Badge({ children, tone = 'lime' }: { children: ReactNode; tone?: 'lime' | 'gold' | 'emerald' | 'cyan' | 'muted' }) {
  const map = {
    lime: 'bg-neon/15 text-lime-700 ring-neon/30 dark:text-lime-300',
    gold: 'bg-gold/15 text-amber-700 ring-gold/30 dark:text-amber-300',
    emerald: 'bg-bio/15 text-emerald-700 ring-bio/30 dark:text-emerald-300',
    cyan: 'bg-cyan-500/15 text-cyan-700 ring-cyan-500/30 dark:text-cyan-300',
    muted: 'bg-chip text-ink-2 ring-line',
  }
  return (
    <span className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider ring-1 ${map[tone]}`}>
      {children}
    </span>
  )
}
