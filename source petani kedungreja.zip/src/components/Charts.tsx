import { motion } from 'framer-motion'
import { Bug, CalendarRange, Droplets, PieChart as PieIcon, Shovel } from 'lucide-react'
import { useState, type ReactNode } from 'react'
import { Bar, BarChart, CartesianGrid, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { fmt, type Inputs, type Result } from '@/lib/sop'
import { GlassCard, SectionTitle } from './ui'

// Validated categorical palette (cyan · lime · indigo) — passes CVD & contrast in light and dark.
export const SERIES = { a: '#0891B2', b: '#65A30D', c: '#6366F1' }

function ChartTip({ active, payload, label }: { active?: boolean; payload?: any[]; label?: string }) {
  if (!active || !payload?.length) return null
  return (
    <div className="rounded-xl border border-line bg-glass-strong px-3 py-2 text-[12px] shadow-xl backdrop-blur-xl">
      {label && <div className="mb-1 font-bold text-ink">{label}</div>}
      {payload
        .filter((p) => p.value > 0)
        .map((p) => (
          <div key={p.name} className="flex items-center gap-2 text-ink-2">
            <span className="size-2.5 rounded-sm" style={{ background: p.payload?.fill ?? p.color }} />
            <span>{p.name}</span>
            <span className="tabular ml-auto pl-3 font-bold text-ink">{fmt(p.value)} kg</span>
          </div>
        ))}
    </div>
  )
}

export function UreaDoughnut({ r }: { r: Result }) {
  const data = [
    { name: 'Dasar · 7–10 HST', value: r.urea.dasar, fill: SERIES.a },
    { name: 'Susulan I · 20–25 HST', value: r.urea.susulan1, fill: SERIES.b },
    { name: 'Susulan II · 35–40 HST', value: r.urea.susulan2, fill: SERIES.c },
  ]
  const total = r.urea.total || 1
  // Round so the three shares always sum to exactly 100%.
  const shares = data.map((d) => Math.round((d.value / total) * 1000) / 10)
  shares[2] = Math.round((100 - shares[0] - shares[1]) * 10) / 10

  return (
    <GlassCard glow="radial-gradient(50% 50% at 50% 30%, rgb(132 204 22 / 0.22), transparent)">
      <div className="text-[13px] font-bold text-ink">Proporsi Alokasi Urea per Fase Tumbuh</div>
      <div className="text-[11px] text-ink-3">Total {fmt(r.urea.total)} kg · disesuaikan BWD & cuaca</div>
      <div className="relative mx-auto mt-2 h-56 w-full max-w-[260px]">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              dataKey="value"
              nameKey="name"
              innerRadius="64%"
              outerRadius="92%"
              paddingAngle={3}
              cornerRadius={6}
              stroke="none"
              animationDuration={900}
              animationEasing="ease-out"
            >
              {data.map((d) => (
                <Cell key={d.name} fill={d.fill} />
              ))}
            </Pie>
            <Tooltip content={<ChartTip />} />
          </PieChart>
        </ResponsiveContainer>
        <div className="pointer-events-none absolute inset-0 grid place-items-center text-center">
          <div>
            <div className="tabular text-3xl font-extrabold tracking-tight text-ink">{fmt(r.urea.total)}</div>
            <div className="text-[11px] font-bold uppercase tracking-wider text-ink-3">kg Urea</div>
          </div>
        </div>
      </div>
      <ul className="mt-2 space-y-1.5">
        {data.map((d, i) => (
          <li key={d.name} className="flex min-h-11 items-center gap-3 rounded-xl bg-chip px-3 ring-1 ring-line">
            <span className="size-3 rounded-[4px]" style={{ background: d.fill }} />
            <span className="text-[12.5px] font-semibold text-ink-2">{d.name}</span>
            <span className="tabular ml-auto text-[12.5px] font-extrabold text-ink">{fmt(d.value)} kg</span>
            <span className="tabular w-12 text-right text-[11.5px] font-bold text-ink-3">{fmt(shares[i])}%</span>
          </li>
        ))}
      </ul>
    </GlassCard>
  )
}

function StageBars({ r }: { r: Result }) {
  const data = [
    { stage: '7 HST', Phonska: r.phonska, Urea: r.urea.dasar, KCl: 0 },
    { stage: '20 HST', Phonska: 0, Urea: r.urea.susulan1, KCl: 0 },
    { stage: '35 HST', Phonska: 0, Urea: r.urea.susulan2, KCl: r.kcl },
  ]
  const series = [
    { key: 'Phonska', color: SERIES.a },
    { key: 'Urea', color: SERIES.b },
    { key: 'KCl', color: SERIES.c },
  ]
  return (
    <div>
      <div className="mb-2 flex flex-wrap gap-3 px-1">
        {series.map((s) => (
          <span key={s.key} className="flex items-center gap-1.5 text-[11px] font-semibold text-ink-2">
            <span className="size-2.5 rounded-[3px]" style={{ background: s.color }} />
            {s.key}
          </span>
        ))}
      </div>
      <div className="h-48">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 8, right: 4, left: -18, bottom: 0 }} barCategoryGap="28%">
            <CartesianGrid vertical={false} stroke="var(--line)" />
            <XAxis dataKey="stage" tickLine={false} axisLine={false} tick={{ fill: 'var(--ink-3)', fontSize: 11, fontWeight: 600 }} />
            <YAxis tickLine={false} axisLine={false} tick={{ fill: 'var(--ink-3)', fontSize: 10 }} width={44} />
            <Tooltip content={<ChartTip />} cursor={{ fill: 'var(--chip)' }} />
            {series.map((s) => (
              <Bar key={s.key} dataKey={s.key} stackId="a" fill={s.color} radius={[4, 4, 4, 4]} stroke="var(--canvas)" strokeWidth={2} animationDuration={800} />
            ))}
          </BarChart>
        </ResponsiveContainer>
      </div>
      <p className="px-1 text-[10.5px] text-ink-3">kg pupuk tanah kimia per aplikasi · organik & dolomit diberikan H-7 (lihat timeline)</p>
    </div>
  )
}

interface Lane {
  soil: string[]
  foliar: string[]
  pest: string[]
}

function Cell3({ icon, tone, items }: { icon: ReactNode; tone: string; items: string[] }) {
  return (
    <div className={`rounded-xl p-2 ring-1 ${items.length ? tone : 'bg-chip ring-line'}`}>
      <div className="mb-1 opacity-80">{icon}</div>
      {items.length ? (
        items.map((t) => (
          <div key={t} className="text-[10.5px] font-semibold leading-snug text-ink">
            {t}
          </div>
        ))
      ) : (
        <div className="text-[10.5px] text-ink-3">—</div>
      )}
    </div>
  )
}

export function MasterTimeline({ r, inputs }: { r: Result; inputs: Inputs }) {
  const [open, setOpen] = useState(2)
  const amino = `Asam Amino ${r.foliar.aminoPerTank} mL/tk`
  const events: { at: string; phase: string; lane: Lane }[] = [
    {
      at: 'H-7',
      phase: 'Olah Tanah & Pra-Tanam',
      lane: {
        soil: [`Organik ${fmt(r.organik, 0)} kg`, ...(r.dolomit > 0 ? [`Dolomit ${fmt(r.dolomit, 0)} kg`] : [])],
        foliar: [],
        pest: ['Sanitasi gulma & jerami', 'Keong mas'],
      },
    },
    {
      at: '7 HST',
      phase: 'Pupuk Dasar',
      lane: {
        soil: [`Phonska ${fmt(r.phonska)} kg`, `Urea ${fmt(r.urea.dasar)} kg`],
        foliar: inputs.plant === 'pemulihan' ? [`${amino} (3–5 HST)`] : [],
        pest: ['Keong mas', 'Tikus sawah'],
      },
    },
    {
      at: '20 HST',
      phase: 'Susulan I · Anakan Aktif',
      lane: {
        soil: [`Urea ${fmt(r.urea.susulan1)} kg`, `Cek BWD (skala ${inputs.bwd})`],
        foliar: [amino, 'Mikro 30 g/tk'],
        pest: ['Sundep (penggerek batang)', 'Wereng hijau'],
      },
    },
    {
      at: '35 HST',
      phase: 'Susulan II · Inisiasi Bunting',
      lane: {
        soil: [`Urea ${fmt(r.urea.susulan2)} kg`, `KCl ${fmt(r.kcl)} kg`],
        foliar: [amino, 'Mikro 30 g/tk', ...(r.foliar.silikaPerTank ? [`Silika ${r.foliar.silikaPerTank} mL/tk`] : [])],
        pest: ['Blast daun', 'Hawar daun bakteri'],
      },
    },
    {
      at: '45 HST',
      phase: 'Bunting · Pra-Malai',
      lane: {
        soil: [],
        foliar: ['Mikro B + Ca 30 g/tk', ...(r.foliar.calciumPerTank ? [`Kalsium +${r.foliar.calciumPerTank} g/tk`] : [])],
        pest: ['Beluk (penggerek batang)', 'Blast leher malai', 'Wereng batang coklat'],
      },
    },
  ]

  return (
    <GlassCard glow="radial-gradient(50% 50% at 70% 0%, rgb(8 145 178 / 0.22), transparent)">
      <div className="text-[13px] font-bold text-ink">Timeline Pemupukan & PHT Kementan</div>
      <div className="mb-3 text-[11px] text-ink-3">Pupuk tanah · semprot foliar · waspada hama, berdampingan</div>
      <StageBars r={r} />
      <div className="mt-4 grid grid-cols-3 gap-1.5 px-1 pl-[52px] text-[9.5px] font-bold uppercase tracking-wider text-ink-3">
        <span className="flex items-center gap-1"><Shovel className="size-3" />Tanah</span>
        <span className="flex items-center gap-1"><Droplets className="size-3" />Foliar</span>
        <span className="flex items-center gap-1"><Bug className="size-3" />Hama</span>
      </div>
      <ol className="relative mt-2 space-y-2">
        <span aria-hidden className="absolute bottom-4 left-[21px] top-4 w-0.5 rounded bg-gradient-to-b from-bio via-neon to-gold opacity-60" />
        {events.map((e, i) => {
          const on = open === i
          return (
            <motion.li key={e.at} layout className="relative flex gap-2.5">
              <button
                onClick={() => setOpen(on ? -1 : i)}
                aria-expanded={on}
                className={`relative z-10 grid size-11 shrink-0 place-items-center rounded-full text-[10px] font-extrabold ring-2 transition ${
                  on
                    ? 'bg-gradient-to-br from-bio to-neon text-emerald-deep ring-neon/50 shadow-[0_0_20px_rgb(132_204_22/0.6)]'
                    : 'bg-glass-strong text-ink ring-line'
                }`}
              >
                {e.at}
              </button>
              <div className="min-w-0 flex-1">
                <button onClick={() => setOpen(on ? -1 : i)} className="flex min-h-11 w-full items-center text-left text-[12.5px] font-bold text-ink">
                  {e.phase}
                </button>
                <motion.div
                  initial={false}
                  animate={{ height: on ? 'auto' : 0, opacity: on ? 1 : 0 }}
                  transition={{ type: 'spring', stiffness: 300, damping: 32 }}
                  className="overflow-hidden"
                >
                  <div className="grid grid-cols-3 gap-1.5 pb-1">
                    <Cell3 icon={<Shovel className="size-3.5 text-cyan-500" />} tone="bg-cyan-500/10 ring-cyan-500/25" items={e.lane.soil} />
                    <Cell3 icon={<Droplets className="size-3.5 text-lime-500" />} tone="bg-lime-500/10 ring-lime-500/25" items={e.lane.foliar} />
                    <Cell3 icon={<Bug className="size-3.5 text-amber-500" />} tone="bg-amber-500/10 ring-amber-500/25" items={e.lane.pest} />
                  </div>
                </motion.div>
              </div>
            </motion.li>
          )
        })}
      </ol>
    </GlassCard>
  )
}

export function ChartsSection({ r, inputs }: { r: Result; inputs: Inputs }) {
  return (
    <section className="space-y-4">
      <SectionTitle icon={<PieIcon className="size-4.5" />} eyebrow="Visualisasi" title="Analitik Alokasi & Jadwal" />
      <UreaDoughnut r={r} />
      <div className="flex items-center gap-2 px-1 pt-2 text-[12px] font-bold text-ink-2">
        <CalendarRange className="size-4 text-neon" /> Ketuk tanggal untuk membuka detail fase
      </div>
      <MasterTimeline r={r} inputs={inputs} />
    </section>
  )
}
