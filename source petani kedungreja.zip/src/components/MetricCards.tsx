import { AnimatePresence, motion } from 'framer-motion'
import { Beaker, Droplets, Layers, Mountain, Package, Recycle, Sparkles } from 'lucide-react'
import { useRef, useState, type ReactNode } from 'react'
import { fmt, type Result } from '@/lib/sop'
import { AnimatedNumber, Badge, SectionTitle } from './ui'

interface CardDef {
  key: string
  title: string
  value: number
  digits?: number
  unit: string
  note: string
  icon: ReactNode
  badge?: ReactNode
  glow: string
  extra?: ReactNode
}

function StatCard({ c, index }: { c: CardDef; index: number }) {
  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 24, scale: 0.94 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      transition={{ type: 'spring', stiffness: 260, damping: 24, delay: index * 0.05 }}
      whileTap={{ scale: 0.97 }}
      className="relative w-[78%] max-w-[300px] shrink-0 snap-center first:ml-1 last:mr-1"
    >
      <div aria-hidden className="pointer-events-none absolute -inset-2 rounded-[32px] opacity-70 blur-2xl dark:opacity-55" style={{ background: c.glow }} />
      <div className="relative flex h-full min-h-[208px] flex-col overflow-hidden rounded-[26px] border border-line bg-glass p-5 backdrop-blur-xl">
        <div aria-hidden className="absolute -right-10 -top-10 size-32 rounded-full opacity-40 blur-2xl" style={{ background: c.glow }} />
        <div className="relative flex items-start justify-between gap-2">
          <div className="grid size-11 place-items-center rounded-2xl bg-chip text-ink ring-1 ring-line">{c.icon}</div>
          {c.badge}
        </div>
        <div className="relative mt-4 text-[12.5px] font-bold text-ink-2">{c.title}</div>
        <div className="relative mt-1 flex items-baseline gap-1.5">
          <AnimatedNumber value={c.value} digits={c.digits ?? 1} className="text-[40px] font-extrabold leading-none tracking-tight text-ink" />
          <span className="text-[15px] font-bold text-ink-3">{c.unit}</span>
        </div>
        <div className="relative mt-1.5 text-[11.5px] font-medium text-ink-3">{c.note}</div>
        {c.extra && <div className="relative mt-auto pt-3">{c.extra}</div>}
      </div>
    </motion.article>
  )
}

function Carousel({ cards }: { cards: CardDef[] }) {
  const ref = useRef<HTMLDivElement>(null)
  const [active, setActive] = useState(0)
  return (
    <div>
      <div
        ref={ref}
        onScroll={(e) => {
          const el = e.currentTarget
          const w = el.scrollWidth / cards.length
          setActive(Math.min(cards.length - 1, Math.round(el.scrollLeft / w)))
        }}
        className="no-scrollbar -mx-4 flex snap-x snap-mandatory gap-3 overflow-x-auto px-4 py-4"
      >
        <AnimatePresence initial={false} mode="popLayout">
          {cards.map((c, i) => (
            <StatCard key={c.key} c={c} index={i} />
          ))}
        </AnimatePresence>
      </div>
      {cards.length > 1 && (
        <div className="flex justify-center gap-1.5">
          {cards.map((c, i) => (
            <motion.span
              key={c.key}
              animate={{ width: i === active ? 22 : 6, opacity: i === active ? 1 : 0.4 }}
              className="h-1.5 rounded-full bg-neon"
            />
          ))}
        </div>
      )}
    </div>
  )
}

function Pill({ label, value }: { label: string; value: number }) {
  return (
    <div className="flex-1 rounded-xl bg-chip px-2 py-1.5 text-center ring-1 ring-line">
      <div className="text-[9.5px] font-bold uppercase tracking-wider text-ink-3">{label}</div>
      <div className="tabular text-[12.5px] font-extrabold text-ink">{fmt(value)} kg</div>
    </div>
  )
}

export function MetricCards({ r }: { r: Result }) {
  const utama: CardDef[] = [
    {
      key: 'phonska',
      title: 'NPK Phonska 15-15-15',
      value: r.phonska,
      unit: 'kg',
      note: '100% diberikan saat Pupuk Dasar · 7–10 HST',
      icon: <Package className="size-5 text-cyan-500" />,
      badge: <Badge tone="emerald">Subsidi</Badge>,
      glow: 'radial-gradient(closest-side, rgb(8 145 178 / 0.55), transparent)',
    },
    {
      key: 'urea',
      title: 'Urea 46% N',
      value: r.urea.total,
      unit: 'kg',
      note: 'Dibagi 3 fase sesuai fase tumbuh',
      icon: <Layers className="size-5 text-lime-500" />,
      badge: <Badge tone="emerald">Subsidi</Badge>,
      glow: 'radial-gradient(closest-side, rgb(132 204 22 / 0.5), transparent)',
      extra: (
        <div className="flex gap-1.5">
          <Pill label="Dasar" value={r.urea.dasar} />
          <Pill label="Sus. I" value={r.urea.susulan1} />
          <Pill label="Sus. II" value={r.urea.susulan2} />
        </div>
      ),
    },
  ]

  const pelengkap: CardDef[] = [
    {
      key: 'organik',
      title: 'Pupuk Organik / Kompos',
      value: r.organik,
      unit: 'kg',
      note: 'Pra-tanam H-7 · sebar & bajak rata',
      icon: <Recycle className="size-5 text-emerald-500" />,
      badge: <Badge tone="lime">Disarankan</Badge>,
      glow: 'radial-gradient(closest-side, rgb(5 150 105 / 0.55), transparent)',
    },
    {
      key: 'kcl',
      title: 'KCl 60% K₂O · Generatif',
      value: r.kcl,
      unit: 'kg',
      note: 'Bersama Susulan II · 35–40 HST',
      icon: <Sparkles className="size-5 text-indigo-400" />,
      badge: <Badge tone="cyan">Booster Gabah</Badge>,
      glow: 'radial-gradient(closest-side, rgb(99 102 241 / 0.5), transparent)',
    },
  ]
  if (r.dolomit > 0)
    pelengkap.push({
      key: 'dolomit',
      title: 'Dolomit / Kapur Pertanian',
      value: r.dolomit,
      unit: 'kg',
      note: 'Netralisir tanah masam · H-7 sebelum tanam',
      icon: <Mountain className="size-5 text-amber-500" />,
      badge: <Badge tone="gold">pH Masam</Badge>,
      glow: 'radial-gradient(closest-side, rgb(217 119 6 / 0.55), transparent)',
    })
  pelengkap.push({
    key: 'tank',
    title: 'Tangki Semprot 16 L',
    value: r.foliar.tanks,
    digits: 0,
    unit: 'tangki',
    note: `${fmt(r.foliar.waterL, 0)} L air · per aplikasi semprot`,
    icon: <Droplets className="size-5 text-sky-400" />,
    badge: <Badge tone="lime">Foliar</Badge>,
    glow: 'radial-gradient(closest-side, rgb(56 189 248 / 0.45), transparent)',
    extra: (
      <div className="flex gap-1.5">
        <div className="flex-1 rounded-xl bg-chip px-2 py-1.5 text-center ring-1 ring-line">
          <div className="text-[9.5px] font-bold uppercase tracking-wider text-ink-3">Asam Amino</div>
          <div className="tabular text-[12.5px] font-extrabold text-ink">{fmt(r.foliar.aminoTotal, 0)} mL</div>
        </div>
        <div className="flex-1 rounded-xl bg-chip px-2 py-1.5 text-center ring-1 ring-line">
          <div className="text-[9.5px] font-bold uppercase tracking-wider text-ink-3">Mikro Zn·B·Ca</div>
          <div className="tabular text-[12.5px] font-extrabold text-ink">{fmt(r.foliar.mikroTotal, 0)} g</div>
        </div>
      </div>
    ),
  })

  return (
    <div className="space-y-6">
      <section>
        <SectionTitle icon={<Package className="size-4.5" />} eyebrow="Kategori 1 · Subsidi Pemerintah" title="Pupuk Utama (Wajib)" />
        <Carousel cards={utama} />
      </section>
      <section>
        <SectionTitle icon={<Beaker className="size-4.5" />} eyebrow="Kategori 2 · Non-Subsidi" title="Nutrisi Pelengkap (Opsional / Disarankan)" />
        <Carousel cards={pelengkap} />
      </section>
    </div>
  )
}
