import { AnimatePresence, motion } from 'framer-motion'
import {
  CloudRain,
  FlaskConical,
  Gauge,
  HeartPulse,
  Leaf,
  Map as MapIcon,
  Sprout,
  Sun,
  Target,
  TrendingUp,
} from 'lucide-react'
import { useEffect, useState } from 'react'
import {
  BWD_COLORS,
  UNIT_META,
  fmt,
  fromUbin,
  toUbin,
  type AreaUnit,
  type Inputs,
  type Result,
} from '@/lib/sop'
import { GlassCard, SectionTitle, Segmented, spring } from './ui'

type Setter = <K extends keyof Inputs>(k: K, v: Inputs[K]) => void

function Label({ icon, children, hint }: { icon: React.ReactNode; children: React.ReactNode; hint?: React.ReactNode }) {
  return (
    <div className="mb-2.5 flex items-center justify-between gap-2">
      <div className="flex items-center gap-2 text-[13px] font-bold text-ink">
        <span className="text-bio dark:text-neon">{icon}</span>
        {children}
      </div>
      {hint}
    </div>
  )
}

function AreaInput({ inputs, set, result }: { inputs: Inputs; set: Setter; result: Result }) {
  const meta = UNIT_META[inputs.unit]
  const [draft, setDraft] = useState(String(inputs.area))
  useEffect(() => {
    if (parseFloat(draft) !== inputs.area) setDraft(String(inputs.area))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [inputs.area])

  const pct = Math.min(100, (inputs.area / meta.max) * 100)
  const changeUnit = (u: AreaUnit) => {
    const ubin = toUbin(inputs.area, inputs.unit)
    const next = fromUbin(ubin, u)
    const rounded = u === 'ha' ? Math.round(next * 1000) / 1000 : Math.round(next)
    set('unit', u)
    set('area', rounded)
  }

  return (
    <div>
      <Label icon={<MapIcon className="size-4" />}>Luas Lahan</Label>
      <div className="flex items-stretch gap-2">
        <div className="relative flex-1">
          <input
            type="number"
            inputMode="decimal"
            min={0}
            step={meta.step}
            value={draft}
            onChange={(e) => {
              setDraft(e.target.value)
              const n = parseFloat(e.target.value)
              set('area', isNaN(n) || n < 0 ? 0 : n)
            }}
            aria-label="Luas lahan"
            className="tabular h-16 w-full rounded-2xl border border-line bg-chip px-4 text-3xl font-extrabold tracking-tight text-ink outline-none transition focus:border-neon/60 focus:ring-4 focus:ring-neon/15"
          />
        </div>
        <select
          value={inputs.unit}
          onChange={(e) => changeUnit(e.target.value as AreaUnit)}
          aria-label="Satuan luas"
          className="h-16 w-[118px] rounded-2xl border border-line bg-chip px-3 text-[13px] font-bold text-ink outline-none focus:border-neon/60"
        >
          {(Object.keys(UNIT_META) as AreaUnit[]).map((u) => (
            <option key={u} value={u} className="bg-white text-black">
              {UNIT_META[u].label}
            </option>
          ))}
        </select>
      </div>
      <input
        type="range"
        min={0}
        max={meta.max}
        step={meta.step}
        value={Math.min(inputs.area, meta.max)}
        onChange={(e) => set('area', parseFloat(e.target.value))}
        aria-label="Geser luas lahan"
        className="range mt-5 w-full"
        style={{ ['--pct' as string]: `${pct}%` }}
      />
      <div className="mt-3 grid grid-cols-3 gap-2 text-center">
        {[
          { v: fmt(result.ubin, 0), u: 'Ubin' },
          { v: fmt(result.m2, 0), u: 'm²' },
          { v: fmt(result.ha, 3), u: 'Hektar' },
        ].map((c) => (
          <div key={c.u} className="rounded-xl bg-chip px-2 py-2 ring-1 ring-line">
            <div className="tabular text-[14px] font-extrabold text-ink">{c.v}</div>
            <div className="text-[10px] font-semibold uppercase tracking-wider text-ink-3">{c.u}</div>
          </div>
        ))}
      </div>
      <p className="mt-2 px-1 text-[11px] text-ink-3">1 Ubin / Bata = 14 m² · 1 Hektar ≈ 714,28 Ubin</p>
    </div>
  )
}

function BwdSelector({ value, onChange }: { value: number; onChange: (n: number) => void }) {
  return (
    <div>
      <Label
        icon={<Leaf className="size-4" />}
        hint={
          <AnimatePresence>
            {value >= 4 && (
              <motion.span
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                className="rounded-full bg-gold/15 px-2.5 py-1 text-[10px] font-bold text-amber-700 ring-1 ring-gold/30 dark:text-amber-300"
              >
                Urea Susulan I −20%
              </motion.span>
            )}
          </AnimatePresence>
        }
      >
        Bagan Warna Daun (BWD)
      </Label>
      <div className="relative grid grid-cols-5 gap-2 rounded-2xl bg-chip p-2 ring-1 ring-line" role="radiogroup" aria-label="Skala BWD">
        {BWD_COLORS.map((c, idx) => {
          const n = idx + 1
          const on = n === value
          return (
            <motion.button
              key={n}
              role="radio"
              aria-checked={on}
              aria-label={`Skala ${n}`}
              whileTap={{ scale: 0.9 }}
              transition={spring}
              onClick={() => onChange(n)}
              className="relative flex min-h-16 flex-col items-center justify-end rounded-xl pb-1.5"
              style={{ background: `linear-gradient(180deg, ${c}, ${c}dd)` }}
            >
              {on && (
                <motion.span
                  layoutId="bwd-ring"
                  transition={spring}
                  className="absolute -inset-1 rounded-[14px] ring-[3px] ring-neon shadow-[0_0_24px_rgb(132_204_22/0.6)]"
                />
              )}
              <span className={`relative text-[15px] font-extrabold ${n <= 2 ? 'text-emerald-950' : 'text-white'}`}>{n}</span>
            </motion.button>
          )
        })}
      </div>
      <div className="mt-2 flex justify-between px-1 text-[10px] font-semibold text-ink-3">
        <span>Kuning pucat · kurang N</span>
        <span>Hijau tua · N cukup</span>
      </div>
    </div>
  )
}

export function InputsPanel({ inputs, set, result }: { inputs: Inputs; set: Setter; result: Result }) {
  return (
    <section>
      <SectionTitle icon={<Gauge className="size-4.5" />} eyebrow="Langkah 1" title="Data Lahan & Kondisi Tanaman" />
      <GlassCard glow="radial-gradient(60% 50% at 30% 0%, rgb(5 150 105 / 0.35), transparent)">
        <div className="space-y-7">
          <AreaInput inputs={inputs} set={set} result={result} />

          <div>
            <Label icon={<FlaskConical className="size-4" />}>Kondisi pH Tanah</Label>
            <Segmented
              id="soil"
              value={inputs.soil}
              onChange={(v) => set('soil', v)}
              tone={inputs.soil === 'masam' ? 'gold' : 'green'}
              options={[
                { value: 'normal', label: 'Normal', sub: 'pH ≥ 5.5' },
                { value: 'masam', label: 'Tanah Masam', sub: 'pH < 5.5 · + Dolomit' },
              ]}
            />
          </div>

          <div>
            <Label icon={<CloudRain className="size-4" />}>Mitigasi Cuaca</Label>
            <Segmented
              id="weather"
              value={inputs.weather}
              onChange={(v) => set('weather', v)}
              options={[
                { value: 'normal', label: 'Normal', icon: <Sprout className="size-4" /> },
                { value: 'hujan', label: 'Hujan Ekstrem', icon: <CloudRain className="size-4" /> },
                { value: 'kemarau', label: 'Kemarau', icon: <Sun className="size-4" /> },
              ]}
            />
            <AnimatePresence initial={false}>
              {inputs.weather !== 'normal' && (
                <motion.p
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="overflow-hidden px-1 pt-2 text-[11.5px] font-medium text-ink-2"
                >
                  {inputs.weather === 'hujan'
                    ? 'Urea dikurangi 15% (rawan tercuci), KCl +20% dan Silika cair ditambahkan untuk batang kokoh.'
                    : 'Asam Amino dinaikkan ke 45 mL/tangki dan Kalsium foliar +15 g/tangki untuk ketahanan stres air.'}
                </motion.p>
              )}
            </AnimatePresence>
          </div>

          <BwdSelector value={inputs.bwd} onChange={(n) => set('bwd', n)} />

          <div>
            <Label icon={<HeartPulse className="size-4" />}>Kondisi Tanaman</Label>
            <Segmented
              id="plant"
              value={inputs.plant}
              onChange={(v) => set('plant', v)}
              options={[
                { value: 'normal', label: 'Kondisi Normal' },
                { value: 'pemulihan', label: 'Pemulihan Stres', sub: 'Pindah Tanam' },
              ]}
            />
            <AnimatePresence>
              {inputs.plant === 'pemulihan' && (
                <motion.div
                  initial={{ opacity: 0, y: -6 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -6 }}
                  className="mt-3 flex flex-wrap gap-2"
                >
                  {['Asam Amino 3–5 HST', 'Pemulihan Akar', 'Anti Stres Transplanting'].map((t, idx) => (
                    <motion.span
                      key={t}
                      initial={{ scale: 0.6, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      transition={{ ...spring, delay: idx * 0.06 }}
                      className="relative rounded-full bg-neon/15 px-3 py-1.5 text-[11px] font-bold text-lime-700 ring-1 ring-neon/40 shadow-[0_0_18px_rgb(132_204_22/0.45)] dark:text-lime-300"
                    >
                      <span className="mr-1.5 inline-block size-1.5 animate-pulse rounded-full bg-neon align-middle" />
                      {t}
                    </motion.span>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <div>
            <Label icon={<Target className="size-4" />}>Target Hasil Panen</Label>
            <Segmented
              id="target"
              value={inputs.target}
              onChange={(v) => set('target', v)}
              options={[
                { value: 'standar', label: 'Standar', sub: '6–8 Ton/Ha · Subsidi' },
                { value: 'intensif', label: 'Intensif', sub: '>8 Ton/Ha · +KCl & Organik', icon: <TrendingUp className="size-4" /> },
              ]}
            />
          </div>
        </div>
      </GlassCard>
    </section>
  )
}
