import { AnimatePresence, motion } from 'framer-motion'
import { AlertTriangle, Clock, Download, FileWarning, Loader2, MessageCircle, RotateCcw, Wallet, Wind } from 'lucide-react'
import { useState } from 'react'
import { DEFAULT_PRICES, LEGAL_TEXT, LEGAL_TITLE, costLines, fmt, rupiah, type Prices, type Result } from '@/lib/sop'
import { AnimatedNumber, GlassCard, SectionTitle, spring } from './ui'

export function RabCard({ r, prices, setPrices }: { r: Result; prices: Prices; setPrices: (p: Prices) => void }) {
  const lines = costLines(r, prices)
  const total = lines.reduce((s, l) => s + l.cost, 0)
  const subsidi = lines.filter((l) => l.subsidi).reduce((s, l) => s + l.cost, 0)
  const perHa = r.ha > 0 ? total / r.ha : 0

  return (
    <section>
      <SectionTitle icon={<Wallet className="size-4.5" />} eyebrow="Anggaran" title="RAB · Estimasi Biaya Pupuk" />
      <GlassCard glow="radial-gradient(60% 60% at 80% 0%, rgb(217 119 6 / 0.28), transparent)">
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-emerald-deep via-[#063b36] to-bio p-5 text-white ring-1 ring-white/10">
          <div aria-hidden className="absolute -right-8 -top-12 size-40 rounded-full bg-neon/30 blur-3xl" />
          <div className="relative text-[11px] font-bold uppercase tracking-[0.16em] text-emerald-100/70">Total Estimasi Anggaran</div>
          <div className="relative mt-1 flex items-baseline gap-1">
            <span className="text-lg font-bold text-neon">Rp</span>
            <AnimatedNumber value={total} digits={0} className="text-[34px] font-extrabold leading-none tracking-tight" />
          </div>
          <div className="relative mt-3 flex gap-2 text-[11px] font-semibold">
            <span className="rounded-full bg-white/10 px-2.5 py-1">Subsidi {rupiah(subsidi)}</span>
            <span className="rounded-full bg-white/10 px-2.5 py-1">≈ {rupiah(perHa)}/Ha</span>
          </div>
        </div>

        <div className="mt-4 flex items-center justify-between px-1">
          <div className="text-[12px] font-bold text-ink-2">Harga lokal (bisa diubah)</div>
          <motion.button
            whileTap={{ scale: 0.92 }}
            onClick={() => setPrices(DEFAULT_PRICES)}
            className="flex min-h-11 items-center gap-1.5 rounded-xl px-3 text-[11.5px] font-bold text-ink-3"
          >
            <RotateCcw className="size-3.5" /> Reset HET
          </motion.button>
        </div>
        <ul className="space-y-2">
          {lines.map((l) => (
            <li key={l.key} className="rounded-2xl bg-chip p-3 ring-1 ring-line">
              <div className="flex items-center justify-between gap-2">
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5 text-[12.5px] font-bold text-ink">
                    {l.label}
                    {l.subsidi && <span className="rounded-md bg-bio/15 px-1.5 py-0.5 text-[9px] font-extrabold uppercase text-emerald-700 dark:text-emerald-300">Subsidi</span>}
                  </div>
                  <div className="tabular text-[11px] text-ink-3">
                    {fmt(l.qty, 2)} {l.unit}
                  </div>
                </div>
                <div className="tabular text-right text-[13.5px] font-extrabold text-ink">{rupiah(l.cost)}</div>
              </div>
              <label className="mt-2 flex h-12 items-center gap-2 rounded-xl border border-line bg-glass-strong px-3 focus-within:border-neon/60 focus-within:ring-4 focus-within:ring-neon/15">
                <span className="text-[12px] font-bold text-ink-3">Rp</span>
                <input
                  type="number"
                  inputMode="numeric"
                  min={0}
                  value={prices[l.key] || ''}
                  onChange={(e) => setPrices({ ...prices, [l.key]: Math.max(0, parseFloat(e.target.value) || 0) })}
                  aria-label={`Harga ${l.label} ${l.priceUnit}`}
                  className="tabular w-full bg-transparent text-[14px] font-bold text-ink outline-none"
                />
                <span className="text-[11.5px] font-semibold text-ink-3">{l.priceUnit}</span>
              </label>
            </li>
          ))}
        </ul>
        <p className="mt-3 px-1 text-[10.5px] text-ink-3">Harga awal mengacu HET pupuk bersubsidi & rata-rata harga kios non-subsidi. Harga tersimpan di perangkat ini.</p>
      </GlassCard>
    </section>
  )
}

export function SprayProtocol({ r }: { r: Result }) {
  return (
    <section>
      <SectionTitle icon={<Wind className="size-4.5" />} eyebrow="Protokol Semprot" title="Tank-Mix & Air" />
      <div className="relative overflow-hidden rounded-[26px] border border-line bg-glass p-5 backdrop-blur-xl">
        <div aria-hidden className="absolute -left-16 -top-16 size-48 rounded-full bg-sky-400/20 blur-3xl" />
        <div className="relative flex items-center gap-4">
          <div className="grid size-14 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-sky-500 to-cyan-600 text-white shadow-[0_10px_30px_-8px_rgb(14_165_233/0.8)]">
            <Clock className="size-7" />
          </div>
          <div>
            <div className="text-[11px] font-bold uppercase tracking-wider text-ink-3">Jam Semprot Optimal</div>
            <div className="tabular text-2xl font-extrabold tracking-tight text-ink">06:00 – 09:00 WIB</div>
            <div className="text-[11.5px] text-ink-2">Stomata terbuka, angin tenang, tidak ada hujan 4 jam ke depan</div>
          </div>
        </div>
        <div className="relative mt-4 grid grid-cols-3 gap-2">
          {[
            { k: 'Air / tangki', v: '16 L' },
            { k: 'Asam Amino', v: `${r.foliar.aminoPerTank} mL` },
            { k: 'Mikro Zn·B·Ca', v: `${r.foliar.mikroPerTank + r.foliar.calciumPerTank} g` },
          ].map((x) => (
            <div key={x.k} className="rounded-xl bg-chip p-2.5 text-center ring-1 ring-line">
              <div className="tabular text-[15px] font-extrabold text-ink">{x.v}</div>
              <div className="text-[10px] font-semibold text-ink-3">{x.k}</div>
            </div>
          ))}
        </div>
        <ol className="relative mt-4 space-y-1.5 text-[12px] text-ink-2">
          {['Isi ½ tangki air bersih (pH 5,5–6,5)', 'Masukkan unsur mikro, aduk rata', 'Tambahkan asam amino, penuhi air hingga 16 L', 'Semprot merata ke permukaan & bawah daun'].map((s, i) => (
            <li key={s} className="flex gap-2.5">
              <span className="grid size-5 shrink-0 place-items-center rounded-full bg-neon/20 text-[10px] font-extrabold text-lime-700 dark:text-lime-300">{i + 1}</span>
              {s}
            </li>
          ))}
        </ol>
        <motion.div
          animate={{ boxShadow: ['0 0 0px rgb(217 119 6 / 0)', '0 0 28px rgb(217 119 6 / 0.45)', '0 0 0px rgb(217 119 6 / 0)'] }}
          transition={{ duration: 2.6, repeat: Infinity }}
          className="relative mt-4 flex items-start gap-3 rounded-2xl border border-gold/40 bg-gold/12 p-3.5"
        >
          <AlertTriangle className="mt-0.5 size-5 shrink-0 text-gold" />
          <div className="text-[12.5px] font-bold leading-snug text-amber-800 dark:text-amber-200">
            Dilarang mencampur Asam Amino dengan Fungisida Tembaga (Cu)!
            <div className="mt-0.5 text-[11px] font-medium text-amber-700/80 dark:text-amber-200/70">Beri jeda minimal 3 hari antar aplikasi.</div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}

export function LegalFooter() {
  return (
    <footer className="rounded-[26px] border-2 border-gold/35 bg-gold/8 p-5">
      <div className="flex items-center gap-2 text-[12px] font-extrabold tracking-wide text-amber-700 dark:text-amber-300">
        <FileWarning className="size-4.5" /> {LEGAL_TITLE}
      </div>
      <p className="mt-2 text-[12.5px] leading-relaxed text-ink-2">{LEGAL_TEXT}</p>
      <div className="mt-4 border-t border-line pt-3 text-[10.5px] text-ink-3">
        © {new Date().getFullYear()} Petani Kedungreja · Acuan SOP Kementan RI / BSIP · Dibuat untuk petani Indonesia 🌾
      </div>
    </footer>
  )
}

export function ActionBar({ onPdf, onWa }: { onPdf: () => Promise<void>; onWa: () => void }) {
  const [busy, setBusy] = useState(false)
  const [toast, setToast] = useState<string | null>(null)
  const flash = (t: string) => {
    setToast(t)
    setTimeout(() => setToast(null), 2200)
  }
  return (
    <div className="fixed inset-x-0 bottom-0 z-40 px-3 pb-[max(env(safe-area-inset-bottom),12px)]">
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ y: 12, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 12, opacity: 0 }}
            className="mx-auto mb-2 w-fit rounded-full bg-emerald-deep px-4 py-2 text-[12px] font-bold text-neon shadow-xl ring-1 ring-neon/30"
          >
            {toast}
          </motion.div>
        )}
      </AnimatePresence>
      <div className="mx-auto max-w-md rounded-[26px] border border-line bg-glass-strong p-2 shadow-[0_-10px_40px_-10px_rgb(0_0_0/0.5)] backdrop-blur-2xl">
        <div className="grid grid-cols-2 gap-2">
          <motion.button
            whileTap={{ scale: 0.95 }}
            transition={spring}
            disabled={busy}
            onClick={async () => {
              setBusy(true)
              try {
                await onPdf()
                flash('PDF resep berhasil diunduh')
              } finally {
                setBusy(false)
              }
            }}
            className="flex min-h-14 items-center justify-center gap-2 rounded-[20px] bg-chip px-3 text-[12.5px] font-extrabold leading-tight text-ink ring-1 ring-line"
          >
            {busy ? <Loader2 className="size-5 animate-spin" /> : <Download className="size-5 text-bio dark:text-neon" />}
            <span className="text-left">Download PDF<br />Resep Lengkap</span>
          </motion.button>
          <motion.button
            whileTap={{ scale: 0.95 }}
            transition={spring}
            onClick={onWa}
            className="flex min-h-14 items-center justify-center gap-2 rounded-[20px] bg-gradient-to-br from-[#25D366] to-bio px-3 text-[12.5px] font-extrabold leading-tight text-white shadow-[0_10px_28px_-8px_rgb(37_211_102/0.8)]"
          >
            <MessageCircle className="size-5" />
            <span className="text-left">Kirim Dosis<br />ke WhatsApp</span>
          </motion.button>
        </div>
      </div>
    </div>
  )
}
