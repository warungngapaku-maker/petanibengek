import { createFileRoute } from '@tanstack/react-router'
import { AnimatePresence, motion } from 'framer-motion'
import { BadgeCheck, Wheat, Zap } from 'lucide-react'
import { useCallback, useEffect, useMemo, useState } from 'react'
import { ChartsSection } from '@/components/Charts'
import { DisclaimerModal, Header } from '@/components/Chrome'
import { InputsPanel } from '@/components/InputsPanel'
import { MetricCards } from '@/components/MetricCards'
import { ActionBar, LegalFooter, RabCard, SprayProtocol } from '@/components/Panels'
import { buildWhatsAppText, downloadPdf, shareWhatsApp } from '@/lib/exporters'
import { DEFAULT_INPUTS, DEFAULT_PRICES, calculate, type Inputs, type Prices } from '@/lib/sop'

export const Route = createFileRoute('/')({
  component: Home,
})

const K_DISC = 'pk-disclaimer-v1'
const K_PRICES = 'pk-prices-v1'
const K_THEME = 'pk-theme'

function Home() {
  const [inputs, setInputs] = useState<Inputs>(DEFAULT_INPUTS)
  const [prices, setPricesState] = useState<Prices>(DEFAULT_PRICES)
  const [dark, setDark] = useState(true)
  const [showDisc, setShowDisc] = useState(false)

  useEffect(() => {
    setDark(document.documentElement.classList.contains('dark'))
    try {
      if (!localStorage.getItem(K_DISC)) setShowDisc(true)
      const p = localStorage.getItem(K_PRICES)
      if (p) setPricesState({ ...DEFAULT_PRICES, ...JSON.parse(p) })
    } catch {
      setShowDisc(true)
    }
  }, [])

  const setPrices = (p: Prices) => {
    setPricesState(p)
    try {
      localStorage.setItem(K_PRICES, JSON.stringify(p))
    } catch {}
  }

  const toggleTheme = () => {
    const next = !dark
    setDark(next)
    document.documentElement.classList.toggle('dark', next)
    try {
      localStorage.setItem(K_THEME, next ? 'dark' : 'light')
    } catch {}
  }

  const set = useCallback(<K extends keyof Inputs>(k: K, v: Inputs[K]) => setInputs((s) => ({ ...s, [k]: v })), [])
  const result = useMemo(() => calculate(inputs), [inputs])

  return (
    <div className="relative min-h-screen overflow-x-hidden">
      {/* Ambient aurora */}
      <div aria-hidden className="pointer-events-none fixed inset-0 overflow-hidden">
        <div className="aurora absolute -left-32 -top-40 size-[520px] rounded-full bg-bio/30 blur-[120px] dark:bg-bio/25" />
        <div className="aurora absolute -right-40 top-1/3 size-[420px] rounded-full bg-neon/20 blur-[120px] [animation-delay:-6s] dark:bg-neon/12" />
        <div className="aurora absolute -bottom-40 left-1/4 size-[460px] rounded-full bg-cyan-500/15 blur-[120px] [animation-delay:-11s]" />
        <div className="absolute inset-0 opacity-[0.035] [background-image:radial-gradient(currentColor_1px,transparent_1px)] [background-size:18px_18px]" />
      </div>

      <DisclaimerModal
        open={showDisc}
        onAccept={() => {
          setShowDisc(false)
          try {
            localStorage.setItem(K_DISC, '1')
          } catch {}
        }}
      />

      <div className="relative mx-auto max-w-md px-4 pb-36">
        <Header dark={dark} onToggle={toggleTheme} />

        <motion.section
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ type: 'spring', stiffness: 200, damping: 24 }}
          className="relative mb-7 mt-4 overflow-hidden rounded-[30px] bg-gradient-to-br from-emerald-deep via-[#053d38] to-[#047857] p-6 text-white ring-1 ring-white/10 shadow-[0_30px_60px_-30px_rgb(5_150_105/0.8)]"
        >
          <div aria-hidden className="absolute -right-12 -top-16 size-56 rounded-full bg-neon/30 blur-3xl" />
          <Wheat aria-hidden className="absolute -bottom-6 -right-4 size-40 rotate-12 text-white/[0.06]" strokeWidth={1.2} />
          <div className="relative flex flex-wrap gap-2">
            <span className="inline-flex items-center gap-1 rounded-full bg-white/10 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider ring-1 ring-white/15">
              <BadgeCheck className="size-3.5 text-neon" /> BSIP · Kementan RI
            </span>
            <span className="inline-flex items-center gap-1 rounded-full bg-neon/20 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-neon ring-1 ring-neon/30">
              Target 6–8 Ton/Ha GKP
            </span>
          </div>
          <h1 className="relative mt-4 text-[26px] font-extrabold leading-[1.12] tracking-tight">
            Kalkulator Pemupukan Padi Presisi <span className="bg-gradient-to-r from-neon to-emerald-300 bg-clip-text text-transparent">& Nutrisi Foliar</span>
          </h1>
          <p className="relative mt-2 text-[13px] leading-relaxed text-emerald-50/75">
            Dosis Phonska, Urea, KCl, organik, dolomit dan semprot foliar — dihitung real-time sesuai luas sawah, BWD dan cuaca Anda.
          </p>
          <AnimatePresence initial={false}>
            {result.adjustments.length > 0 && (
              <motion.ul
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="relative mt-4 space-y-1.5 overflow-hidden"
              >
                {result.adjustments.map((a) => (
                  <motion.li
                    key={a}
                    layout
                    initial={{ opacity: 0, x: -8 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="flex items-start gap-2 rounded-xl bg-white/8 px-3 py-2 text-[11.5px] font-semibold ring-1 ring-white/10"
                  >
                    <Zap className="mt-0.5 size-3.5 shrink-0 text-neon" /> {a}
                  </motion.li>
                ))}
              </motion.ul>
            )}
          </AnimatePresence>
        </motion.section>

        <div className="space-y-9">
          <InputsPanel inputs={inputs} set={set} result={result} />
          <MetricCards r={result} />
          <ChartsSection r={result} inputs={inputs} />
          <SprayProtocol r={result} />
          <RabCard r={result} prices={prices} setPrices={setPrices} />
          <LegalFooter />
        </div>
      </div>

      <ActionBar
        onPdf={() => downloadPdf(inputs, result, prices)}
        onWa={() => shareWhatsApp(buildWhatsAppText(inputs, result, prices))}
      />
    </div>
  )
}
