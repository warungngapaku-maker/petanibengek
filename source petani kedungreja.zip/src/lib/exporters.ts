import {
  LEGAL_TEXT,
  LEGAL_TITLE,
  WEATHER_LABEL,
  costLines,
  fmt,
  rupiah,
  type Inputs,
  type Prices,
  type Result,
} from './sop'

function conditionLines(i: Inputs): string[] {
  return [
    `pH Tanah: ${i.soil === 'masam' ? 'Tanah Masam (pH < 5.5)' : 'Normal (pH ≥ 5.5)'}`,
    `Cuaca: ${WEATHER_LABEL[i.weather]}`,
    `BWD: Skala ${i.bwd}`,
    `Tanaman: ${i.plant === 'pemulihan' ? 'Pemulihan Stres / Pindah Tanam' : 'Kondisi Normal'}`,
    `Target: ${i.target === 'intensif' ? 'Intensif High-Yield (>8 Ton/Ha)' : 'Standar (6–8 Ton/Ha)'}`,
  ]
}

export function buildWhatsAppText(i: Inputs, r: Result, p: Prices): string {
  const total = costLines(r, p).reduce((s, l) => s + l.cost, 0)
  const L: string[] = [
    '*🌾 RESEP PEMUPUKAN PADI PRESISI*',
    '_Petani Kedungreja · SOP Kementan RI_',
    '',
    `📐 *Luas Lahan:* ${fmt(r.ubin, 0)} Ubin · ${fmt(r.m2, 0)} m² · ${fmt(r.ha, 3)} Ha`,
    ...conditionLines(i).map((c) => `• ${c}`),
    '',
    '━━━━━━━━━━━━━━━',
    '*✅ A. PUPUK UTAMA (SUBSIDI – WAJIB)*',
    `• NPK Phonska 15-15-15: *${fmt(r.phonska)} kg* (Dasar 7–10 HST)`,
    `• Urea 46% N: *${fmt(r.urea.total)} kg*`,
    `   ‣ Dasar 7–10 HST: ${fmt(r.urea.dasar)} kg`,
    `   ‣ Susulan I 20–25 HST: ${fmt(r.urea.susulan1)} kg`,
    `   ‣ Susulan II 35–40 HST: ${fmt(r.urea.susulan2)} kg`,
    '',
    '*🌿 B. NUTRISI PELENGKAP (NON-SUBSIDI – DISARANKAN)*',
    `• Pupuk Organik / Kompos (H-7): *${fmt(r.organik)} kg*`,
    `• KCl 60% K₂O (35–40 HST): *${fmt(r.kcl)} kg*`,
  ]
  if (r.dolomit > 0) L.push(`• Dolomit / Kapur Pertanian (H-7): *${fmt(r.dolomit)} kg*`)
  L.push(
    '',
    '*💧 C. SEMPROT FOLIAR (Tangki 16 L)*',
    `• Jumlah Tangki: *${r.foliar.tanks} tangki* (${fmt(r.foliar.waterL, 0)} L air)`,
    `• Asam Amino: ${r.foliar.aminoPerTank} mL/tangki → *${fmt(r.foliar.aminoTotal, 0)} mL*`,
    `• Unsur Mikro (Zn, B, Ca): 30 g/tangki → *${fmt(r.foliar.mikroTotal, 0)} g*`,
  )
  if (r.foliar.calciumTotal > 0) L.push(`• Kalsium tambahan: ${r.foliar.calciumPerTank} g/tangki → *${fmt(r.foliar.calciumTotal, 0)} g*`)
  if (r.foliar.silikaTotal > 0) L.push(`• Silika Cair: ${r.foliar.silikaPerTank} mL/tangki → *${fmt(r.foliar.silikaTotal, 0)} mL*`)
  L.push(
    '⏰ Waktu semprot: 06:00–09:00 WIB',
    '⚠️ Dilarang mencampur Asam Amino dengan Fungisida Tembaga (Cu)!',
    '',
    `💰 *Estimasi RAB:* ${rupiah(total)}`,
  )
  if (r.adjustments.length) {
    L.push('', '*Penyesuaian aktif:*', ...r.adjustments.map((a) => `• ${a}`))
  }
  L.push('', '━━━━━━━━━━━━━━━', `_${LEGAL_TITLE}_`, `_${LEGAL_TEXT}_`)
  return L.join('\n')
}

export function shareWhatsApp(text: string) {
  window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank', 'noopener')
}

export async function downloadPdf(i: Inputs, r: Result, p: Prices) {
  const { jsPDF } = await import('jspdf')
  const doc = new jsPDF({ unit: 'mm', format: 'a4' })
  const W = 210
  const M = 16
  let y = 0

  // Header band
  doc.setFillColor(4, 47, 44)
  doc.rect(0, 0, W, 38, 'F')
  doc.setFillColor(132, 204, 22)
  doc.rect(0, 38, W, 1.2, 'F')
  doc.setTextColor(255, 255, 255)
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(17)
  doc.text('Resep Pemupukan Padi Presisi', M, 17)
  doc.setFont('helvetica', 'normal')
  doc.setFontSize(9.5)
  doc.setTextColor(190, 230, 200)
  doc.text('Petani Kedungreja  |  Acuan SOP Kementan RI / BSIP  |  Target 6-8 Ton/Ha GKP', M, 25)
  doc.text(`Dicetak: ${new Date().toLocaleString('id-ID')}`, M, 31)
  y = 50

  const ensure = (h: number) => {
    if (y + h > 280) {
      doc.addPage()
      y = 20
    }
  }
  const section = (title: string, rgb: [number, number, number]) => {
    ensure(14)
    doc.setFillColor(...rgb)
    doc.roundedRect(M, y - 5, W - M * 2, 8, 1.5, 1.5, 'F')
    doc.setTextColor(255, 255, 255)
    doc.setFont('helvetica', 'bold')
    doc.setFontSize(10)
    doc.text(title, M + 3, y)
    y += 9
  }
  const row = (label: string, value: string, sub = false) => {
    ensure(7)
    doc.setTextColor(sub ? 110 : 30, sub ? 110 : 30, sub ? 110 : 30)
    doc.setFont('helvetica', sub ? 'normal' : 'normal')
    doc.setFontSize(sub ? 9 : 10)
    doc.text(label, M + (sub ? 8 : 3), y)
    doc.setFont('helvetica', 'bold')
    doc.text(value, W - M - 3, y, { align: 'right' })
    doc.setDrawColor(230, 230, 230)
    doc.line(M + 3, y + 2, W - M - 3, y + 2)
    y += 7
  }

  section('DATA LAHAN & KONDISI', [5, 150, 105])
  row('Luas Lahan', `${fmt(r.ubin, 0)} Ubin / ${fmt(r.m2, 0)} m2 / ${fmt(r.ha, 3)} Ha`)
  conditionLines(i).forEach((c) => {
    const [k, ...v] = c.split(': ')
    row(k, v.join(': ').replace('≥', '>=').replace('–', '-'))
  })
  y += 4

  section('A. PUPUK UTAMA (SUBSIDI - WAJIB)', [4, 47, 44])
  row('NPK Phonska 15-15-15 (Dasar 7-10 HST)', `${fmt(r.phonska)} kg`)
  row('Urea 46% N - Total', `${fmt(r.urea.total)} kg`)
  row('Dasar 7-10 HST', `${fmt(r.urea.dasar)} kg`, true)
  row('Susulan I 20-25 HST (Anakan Aktif)', `${fmt(r.urea.susulan1)} kg`, true)
  row('Susulan II 35-40 HST (Inisiasi Bunting)', `${fmt(r.urea.susulan2)} kg`, true)
  y += 4

  section('B. NUTRISI PELENGKAP (NON-SUBSIDI - DISARANKAN)', [77, 124, 15])
  row('Pupuk Organik / Kompos (Pra-Tanam H-7)', `${fmt(r.organik)} kg`)
  row('KCl 60% K2O (Generatif 35-40 HST)', `${fmt(r.kcl)} kg`)
  if (r.dolomit > 0) row('Dolomit / Kapur Pertanian (H-7)', `${fmt(r.dolomit)} kg`)
  y += 4

  section('C. SEMPROT FOLIAR (TANGKI 16 L, 20 UBIN/TANGKI)', [8, 145, 178])
  row('Jumlah Tangki', `${r.foliar.tanks} tangki (${fmt(r.foliar.waterL, 0)} L)`)
  row(`Asam Amino (${r.foliar.aminoPerTank} mL/tangki)`, `${fmt(r.foliar.aminoTotal, 0)} mL`)
  row('Unsur Mikro Zn, B, Ca (30 g/tangki)', `${fmt(r.foliar.mikroTotal, 0)} g`)
  if (r.foliar.calciumTotal > 0) row(`Kalsium tambahan (${r.foliar.calciumPerTank} g/tangki)`, `${fmt(r.foliar.calciumTotal, 0)} g`)
  if (r.foliar.silikaTotal > 0) row(`Silika Cair (${r.foliar.silikaPerTank} mL/tangki)`, `${fmt(r.foliar.silikaTotal, 0)} mL`)
  row('Jam semprot optimal', '06:00 - 09:00 WIB')
  y += 4

  section('ESTIMASI RAB (HARGA LOKAL)', [180, 83, 9])
  const lines = costLines(r, p)
  lines.forEach((l) => row(`${l.label} (${fmt(l.qty, 2)} ${l.unit} x ${rupiah(p[l.key])}${l.priceUnit})`, rupiah(l.cost)))
  row('TOTAL ESTIMASI', rupiah(lines.reduce((s, l) => s + l.cost, 0)))
  y += 4

  if (r.adjustments.length) {
    section('PENYESUAIAN AKTIF', [100, 100, 100])
    doc.setFont('helvetica', 'normal')
    doc.setFontSize(9)
    doc.setTextColor(60, 60, 60)
    r.adjustments.forEach((a) => {
      const t = doc.splitTextToSize(`- ${a.replace(/[−–]/g, '-')}`, W - M * 2 - 6)
      ensure(t.length * 4.5)
      doc.text(t, M + 3, y)
      y += t.length * 4.5 + 1
    })
    y += 3
  }

  // Warning
  ensure(12)
  doc.setFillColor(254, 243, 199)
  doc.roundedRect(M, y - 4, W - M * 2, 10, 1.5, 1.5, 'F')
  doc.setTextColor(146, 64, 14)
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(9.5)
  doc.text('PERINGATAN: Dilarang mencampur Asam Amino dengan Fungisida Tembaga (Cu)!', M + 3, y + 2)
  y += 14

  // Legal
  const legal = doc.splitTextToSize(LEGAL_TEXT.replace(/–/g, '-'), W - M * 2 - 8)
  ensure(legal.length * 4 + 14)
  doc.setDrawColor(4, 47, 44)
  doc.setLineWidth(0.4)
  doc.roundedRect(M, y - 4, W - M * 2, legal.length * 4 + 12, 1.5, 1.5, 'S')
  doc.setTextColor(4, 47, 44)
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(9)
  doc.text(LEGAL_TITLE, M + 4, y + 1.5)
  doc.setFont('helvetica', 'normal')
  doc.setFontSize(8.5)
  doc.setTextColor(60, 60, 60)
  doc.text(legal, M + 4, y + 7)

  doc.save(`Resep-Pupuk-Padi-${fmt(r.ubin, 0)}-Ubin.pdf`)
}
