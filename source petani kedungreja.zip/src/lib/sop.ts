// Mesin kalkulasi dosis pupuk padi — acuan SOP Kementan RI / BSIP (target 6–8 Ton/Ha GKP).

export const M2_PER_UBIN = 14
export const UBIN_PER_HA = 10000 / M2_PER_UBIN // ≈ 714.28
export const TANK_LITERS = 16
export const UBIN_PER_TANK = 20

export type AreaUnit = 'ubin' | 'm2' | 'ha'
export type SoilPh = 'normal' | 'masam'
export type Weather = 'normal' | 'hujan' | 'kemarau'
export type PlantCondition = 'normal' | 'pemulihan'
export type YieldTarget = 'standar' | 'intensif'

export interface Inputs {
  area: number
  unit: AreaUnit
  soil: SoilPh
  weather: Weather
  bwd: number // 1–5
  plant: PlantCondition
  target: YieldTarget
}

export const DEFAULT_INPUTS: Inputs = {
  area: 100,
  unit: 'ubin',
  soil: 'normal',
  weather: 'normal',
  bwd: 3,
  plant: 'normal',
  target: 'standar',
}

export const UNIT_META: Record<AreaUnit, { label: string; short: string; max: number; step: number }> = {
  ubin: { label: 'Ubin / Bata (14 m²)', short: 'Ubin', max: 2000, step: 1 },
  m2: { label: 'Meter Persegi (m²)', short: 'm²', max: 28000, step: 10 },
  ha: { label: 'Hektar (Ha)', short: 'Ha', max: 3, step: 0.01 },
}

export function toUbin(area: number, unit: AreaUnit): number {
  if (unit === 'm2') return area / M2_PER_UBIN
  if (unit === 'ha') return area * UBIN_PER_HA
  return area
}

export function fromUbin(ubin: number, unit: AreaUnit): number {
  if (unit === 'm2') return ubin * M2_PER_UBIN
  if (unit === 'ha') return ubin / UBIN_PER_HA
  return ubin
}

export interface Result {
  ubin: number
  m2: number
  ha: number
  phonska: number
  urea: { total: number; dasar: number; susulan1: number; susulan2: number; baseTotal: number }
  organik: number
  dolomit: number
  kcl: number
  foliar: {
    tanks: number
    waterL: number
    aminoPerTank: number
    aminoTotal: number
    mikroPerTank: number
    mikroTotal: number
    calciumPerTank: number
    calciumTotal: number
    silikaPerTank: number
    silikaTotal: number
  }
  adjustments: string[]
}

export function calculate(i: Inputs): Result {
  const ubin = Math.max(0, toUbin(i.area, i.unit))
  const m2 = ubin * M2_PER_UBIN
  const ha = m2 / 10000
  const adjustments: string[] = []

  // A. Pupuk utama (subsidi)
  const phonska = ha * 250
  const baseUrea = ha * 200
  let ureaTotal = baseUrea
  if (i.weather === 'hujan') {
    ureaTotal *= 0.85
    adjustments.push('Musim hujan ekstrem: Urea −15%, KCl +20%, Silika cair aktif')
  }
  const third = ureaTotal / 3
  let susulan1 = third
  if (i.bwd >= 4) {
    susulan1 *= 0.8
    adjustments.push(`BWD skala ${i.bwd}: Urea Susulan I −20%`)
  }
  const urea = {
    dasar: third,
    susulan1,
    susulan2: third,
    total: third * 2 + susulan1,
    baseTotal: baseUrea,
  }

  // B. Nutrisi pelengkap (non-subsidi)
  const intensif = i.target === 'intensif'
  const organik = ha * (intensif ? 3000 : 2000)
  const dolomit = i.soil === 'masam' ? ha * 1000 : 0
  let kcl = ha * (intensif ? 100 : 50)
  if (i.weather === 'hujan') kcl *= 1.2
  if (intensif) adjustments.push('Target intensif >8 Ton/Ha: KCl 100 kg/Ha & Organik 3 Ton/Ha')
  if (i.soil === 'masam') adjustments.push('Tanah masam: Dolomit 1 Ton/Ha ditambahkan')

  // C. Foliar
  const tanks = ubin > 0 ? Math.ceil(ubin / UBIN_PER_TANK) : 0
  const kemarau = i.weather === 'kemarau'
  const aminoPerTank = kemarau ? 45 : 30
  const calciumPerTank = kemarau ? 15 : 0
  const silikaPerTank = i.weather === 'hujan' ? 20 : 0
  if (kemarau) adjustments.push('Kemarau / stres air: Asam Amino 45 mL & Kalsium +15 g per tangki')
  if (i.plant === 'pemulihan') adjustments.push('Pemulihan stres / pindah tanam: prioritaskan semprot Asam Amino 3–5 HST')

  return {
    ubin,
    m2,
    ha,
    phonska,
    urea,
    organik,
    dolomit,
    kcl,
    foliar: {
      tanks,
      waterL: tanks * TANK_LITERS,
      aminoPerTank,
      aminoTotal: tanks * aminoPerTank,
      mikroPerTank: 30,
      mikroTotal: tanks * 30,
      calciumPerTank,
      calciumTotal: tanks * calciumPerTank,
      silikaPerTank,
      silikaTotal: tanks * silikaPerTank,
    },
    adjustments,
  }
}

// RAB — harga lokal (Rp)
export interface Prices {
  phonska: number // /kg
  urea: number // /kg
  organik: number // /kg
  kcl: number // /kg
  dolomit: number // /kg
  amino: number // /liter
  mikro: number // /kg
  silika: number // /liter
}

export const DEFAULT_PRICES: Prices = {
  phonska: 2300,
  urea: 2250,
  organik: 1000,
  kcl: 12000,
  dolomit: 1500,
  amino: 150000,
  mikro: 100000,
  silika: 120000,
}

export interface CostLine {
  key: keyof Prices
  label: string
  qty: number
  unit: string
  priceUnit: string
  cost: number
  subsidi: boolean
}

export function costLines(r: Result, p: Prices): CostLine[] {
  const lines: CostLine[] = [
    { key: 'phonska', label: 'NPK Phonska', qty: r.phonska, unit: 'kg', priceUnit: '/kg', cost: r.phonska * p.phonska, subsidi: true },
    { key: 'urea', label: 'Urea', qty: r.urea.total, unit: 'kg', priceUnit: '/kg', cost: r.urea.total * p.urea, subsidi: true },
    { key: 'organik', label: 'Pupuk Organik', qty: r.organik, unit: 'kg', priceUnit: '/kg', cost: r.organik * p.organik, subsidi: false },
    { key: 'kcl', label: 'KCl', qty: r.kcl, unit: 'kg', priceUnit: '/kg', cost: r.kcl * p.kcl, subsidi: false },
  ]
  if (r.dolomit > 0)
    lines.push({ key: 'dolomit', label: 'Dolomit', qty: r.dolomit, unit: 'kg', priceUnit: '/kg', cost: r.dolomit * p.dolomit, subsidi: false })
  lines.push(
    { key: 'amino', label: 'Asam Amino', qty: r.foliar.aminoTotal / 1000, unit: 'L', priceUnit: '/L', cost: (r.foliar.aminoTotal / 1000) * p.amino, subsidi: false },
    {
      key: 'mikro',
      label: 'Unsur Mikro (Zn, B, Ca)',
      qty: (r.foliar.mikroTotal + r.foliar.calciumTotal) / 1000,
      unit: 'kg',
      priceUnit: '/kg',
      cost: ((r.foliar.mikroTotal + r.foliar.calciumTotal) / 1000) * p.mikro,
      subsidi: false,
    },
  )
  if (r.foliar.silikaTotal > 0)
    lines.push({ key: 'silika', label: 'Silika Cair', qty: r.foliar.silikaTotal / 1000, unit: 'L', priceUnit: '/L', cost: (r.foliar.silikaTotal / 1000) * p.silika, subsidi: false })
  return lines
}

export const LEGAL_TITLE = 'PENOLAKAN TANGGUNG JAWAB (LEGAL DISCLAIMER):'
export const LEGAL_TEXT =
  'Kalkulasi dosis pupuk pada aplikasi ini merupakan rekomendasi akademis dan panduan umum berbasis acuan standar Kementerian Pertanian RI (BSIP/BBP2TP) untuk target hasil 6–8 Ton/Ha GKP. Dosis efektif di lapangan dapat berbeda tergantung tingkat kesuburan tanah setempat, kondisi iklim, dan varietas benih. Petani Kedungreja tidak bertanggung jawab atas kerugian finansial atau variasi hasil panen akibat faktor lingkungan di luar sistem.'

export const WEATHER_LABEL: Record<Weather, string> = {
  normal: 'Kondisi Normal',
  hujan: 'Musim Hujan Ekstrem',
  kemarau: 'Kemarau / Stres Air',
}

export const BWD_COLORS = ['#C8D96F', '#9DBF3E', '#5E9A2C', '#2F6E22', '#1B4A17']

const nf = (d: number) => new Intl.NumberFormat('id-ID', { maximumFractionDigits: d, minimumFractionDigits: 0 })
export function fmt(n: number, digits = 1): string {
  return nf(digits).format(n)
}
export function rupiah(n: number): string {
  return 'Rp' + nf(0).format(Math.round(n))
}
