# Kalkulator Pemupukan Padi Presisi & Nutrisi Foliar — Petani Kedungreja

A mobile-first web app that calculates rice (padi) fertilizer and foliar spray doses following the Indonesian Ministry of Agriculture (Kementan RI / BSIP) SOP for a 6–8 Ton/Ha GKP yield target.

## Features

- **Land input** in Ubin/Bata (14 m²), m² or Hektar, via slider or direct number entry (default 100 Ubin).
- **Condition toggles**: soil pH (normal / masam → dolomit), weather mitigation (normal / hujan ekstrem / kemarau), 5-step BWD leaf-colour chart, plant recovery mode, yield target (standar / intensif).
- **Live metric cards** split into *Pupuk Utama (Subsidi)* — Phonska & Urea with per-stage breakdown — and *Nutrisi Pelengkap (Non-Subsidi)* — organik, KCl, dolomit, spray tanks & amino acid.
- **Charts**: Urea allocation doughnut, per-stage fertilizer bar chart, and a master timeline (H-7 → 45 HST) showing soil fertilizer, foliar sprays and pest warnings side-by-side.
- **Spray protocol** (06:00–09:00 WIB, tank-mix order, Cu-fungicide warning).
- **RAB cost estimator** with editable local prices (saved in the browser).
- **Exports**: PDF prescription (jsPDF) and a structured WhatsApp message, both ending with the legal disclaimer.
- First-visit disclaimer modal and dark / light mode.

## Tech

TanStack Start (React 19) · Vite 7 · Tailwind CSS 4 · Framer Motion · Recharts · Lucide icons · jsPDF · Netlify.

## Run locally

```bash
pnpm install
pnpm dev            # http://localhost:3000
# or, with Netlify emulation:
netlify dev
```
