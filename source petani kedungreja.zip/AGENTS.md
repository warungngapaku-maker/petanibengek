# AGENTS.md

Mobile-first, single-screen fertilizer calculator for rice farmers ("Petani Kedungreja"), based on the Kementan RI / BSIP SOP. All UI copy is in Bahasa Indonesia. No backend or database — everything is client-side; user preferences live in `localStorage`.

## Stack

TanStack Start (React 19, file routes) · Vite 7 · Tailwind CSS 4 · Framer Motion · Recharts 3 · lucide-react · jsPDF (dynamically imported) · Netlify.

## Structure

```
src/
  lib/sop.ts          # Calculation engine: unit conversion, dose formulas, RAB cost lines, legal text, formatters. Pure functions — edit dosing rules here only.
  lib/exporters.ts    # WhatsApp text builder + jsPDF report (always appends LEGAL_TEXT).
  components/ui.tsx   # Primitives: GlassCard, Segmented (layoutId pill), AnimatedNumber (spring counter), Badge, SectionTitle.
  components/Chrome.tsx      # Sticky header (pulse dot, theme toggle) + first-visit DisclaimerModal.
  components/InputsPanel.tsx # Area slider/number/unit, pH, weather, BWD selector, plant condition, yield target.
  components/MetricCards.tsx # Swipeable scroll-snap carousels for Subsidi / Non-Subsidi stat cards.
  components/Charts.tsx      # Urea doughnut, stage bar chart, MasterTimeline (soil / foliar / pest lanes).
  components/Panels.tsx      # SprayProtocol, RabCard, LegalFooter, sticky ActionBar.
  routes/__root.tsx   # HTML shell, fonts (Plus Jakarta Sans), pre-paint theme script.
  routes/index.tsx    # The app screen: owns inputs/prices/theme state.
  styles.css          # Theme tokens as CSS vars (light :root / .dark), mapped to Tailwind colors (bg-glass, text-ink, border-line…).
```

## Conventions & decisions

- Theme: class-based dark mode (`.dark` on `<html>`, default dark). Use the token colors (`ink`, `ink-2`, `ink-3`, `glass`, `glass-strong`, `line`, `chip`) instead of raw grays so both modes work.
- Chart palette `SERIES` in `Charts.tsx` (cyan #0891B2, lime #65A30D, indigo #6366F1) was validated for CVD separation and contrast in both modes — keep the fixed order (Dasar/Phonska, Susulan I/Urea, Susulan II/KCl).
- SOP assumptions beyond the brief (documented in `sop.ts`): hujan → Urea ×0.85, KCl ×1.2, Silika 20 mL/tank; kemarau → Amino 45 mL/tank + Ca 15 g/tank; intensif → KCl 100 kg/Ha, organik 3 t/Ha; BWD ≥ 4 → Susulan I ×0.8. Foliar totals are per spray application.
- Touch targets ≥ 48px (`min-h-12`/`min-h-14`); main content padded bottom (`pb-36`) for the fixed action bar.
- localStorage keys: `pk-theme`, `pk-disclaimer-v1`, `pk-prices-v1`.
